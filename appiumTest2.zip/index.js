// javascript
const wdio = require("webdriverio");
const assert = require("assert");

const opts = {
  path: '/wd/hub',
  port: 4723,
  maxInstances: 1,
  capabilities: {
    'appium:platformName': "Android",
    'appium:platformVersion': "12",
    'appium:deviceName': "Pixel_2_API_31",
    'appium:app': "../ApiDemos-debug.apk",
    'appium:appPackage': "io.appium.android.apis",
    'appium:appActivity': ".view.TextFields",
    'appium:automationName': "UiAutomator2"
  },
  logLevel: 'trace',
  framework: 'mocha',
  reporters: ['spec'],
  mochaOpts: {
    ui: 'bdd',
    timeout: 60000
  },
};

async function main() {
  client = await wdio.remote(opts);
  const field = await client.$("android.widget.EditText");
  await field.setValue("Hello World!");
  const value = await field.getText();
  assert.strictEqual(value, "Hello World!");
  await client.deleteSession();
  done();
}

main();