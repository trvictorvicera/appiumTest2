// sample
describe('CAV Test Valuation Code', () => {
  beforeEach(() => {
    $("~BeginButton").waitForDisplayed(50000, false)
  });

  it('Valuation Code: Invalid Case', async () => {
    await $("~BeginButton").click();
    const field1 = await $('~ValuationCodeField');
    await field1.setValue("TEST-INVAL");
    await $("~SubmitCodeButton").click();
    $("~ErrorMessage").waitForDisplayed(11000);
    const value = await $("~ErrorMessage").getText();
    await expect(value).toStrictEqual("This valuation code is not valid. Please check and try again.");
  });

  it('Valuation Code: Valid Case Rural', async () => {
    const field1 = await $('~ValuationCodeField');
    await field1.setValue("TEST-RURAL");
    await $("~SubmitCodeButton").click();
    $("~CameraPermDescription").waitForDisplayed(11000);
    const value = await $("~CameraPermDescription").getText();
    await expect(value).toStrictEqual("Throughout this process we will ask you to take some photos to send to the valuer. We need to ask permission to use the camera first.");
  });
});